# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Kashier Payment Acquirer',
    'category': 'Accounting/Payment Acquirers',
    'summary': 'Payment Acquirer: Kashier Implementation',
    'version': '14.0.1.1.0',
    'author': 'Odoo Mates, Odoo SA',
    'description': """Kashier Payment Acquirer""",
    'depends': ['payment'],
    'website': 'http://odoomates.tech',
    'live_test_url': 'https://www.youtube.com/watch?v=Zg0EzM-ogQU',
    'application': True,
    'data': [
        'views/payment_views.xml',
        'views/payment_kashier_templates.xml',
        'data/payment_acquirer_data.xml',
    ],
    'images': ['static/description/banner.png'],
}
