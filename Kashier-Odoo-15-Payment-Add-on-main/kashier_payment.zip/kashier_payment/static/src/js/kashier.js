odoo.define('kashier_payment.kashier', function (require) {
  'use strict';

  var ajax = require('web.ajax');
  var core = require('web.core');
  var _t = core._t;
  var qweb = core.qweb;
  ajax.loadXML(
    '/kashier_payment/static/src/xml/payment_kashier_templates.xml',
    qweb
  );

  require('web.dom_ready');
  if (!$('.o_payment_form').length) {
    return $.Deferred().reject("DOM doesn't contain '.o_payment_form'");
  }

  var observer = new MutationObserver(function (mutations, observer) {
    for (var i = 0; i < mutations.length; ++i) {
      for (var j = 0; j < mutations[i].addedNodes.length; ++j) {
        if (
          mutations[i].addedNodes[j].tagName.toLowerCase() === 'form' &&
          mutations[i].addedNodes[j].getAttribute('provider') == 'kashier'
        ) {
          display_kashier_form($(mutations[i].addedNodes[j]));
        }
      }
    }
  });

  // function kashier_show_error(msg) {
  //   var wizard = $(
  //     qweb.render('kashier.error', { msg: msg || _t('Payment error') })
  //   );
  //   wizard.appendTo($('body')).modal({ keyboard: true });
  // }

  // function kashier_handler(resp) {
  //   if (resp.kashier_payment_id) {
  //     $.post('/payment/kashier/capture', {
  //       payment_id: resp.kashier_payment_id,
  //     })
  //       .done(function (data) {
  //         window.location.href = data;
  //       })
  //       .fail(function (data) {
  //         kashier_show_error(data && data.data && data.data.message);
  //       });
  //   }
  // }

  function display_kashier_form(provider_form) {
    // Open Checkout with further options
    var payment_form = $('.o_payment_form');
    if (!payment_form.find('i').length) {
      payment_form.append('<i class="fa fa-spinner fa-spin"/>');
      payment_form.attr('disabled', 'disabled');
    }

    var get_input_value = function (name) {
      return provider_form.find('input[name="' + name + '"]').val();
    };

    var primaryColor = getComputedStyle(document.body).getPropertyValue(
      '--primary'
    );

    var metaData = {
      ecommercePlatform: 'odoo',
      customerEmail: get_input_value('email'),
      customerPhone: get_input_value('phone'),
      customerName: get_input_value('name'),
    };
    var options = {
      key: get_input_value('key'),
      amount: get_input_value('amount'),
      name: get_input_value('merchant_name'),
      merchantId: get_input_value('merchantId'),
      order_id: get_input_value('order_id'),
      hash: get_input_value('hash'),
      mode: get_input_value('mode'),
      currency_code: get_input_value('currency_code'),
      description: get_input_value('description'),
      lc: get_input_value('lc') ? get_input_value('lc') : 'en',
      return_url: get_input_value('return_url'),
      notify_url: get_input_value('notify_url'),
      color: primaryColor,
      metaData: encodeURIComponent(JSON.stringify(metaData)),
    };
    var script = $('<script>', {
      type: 'text/javascript',
      src: 'https://checkout.kashier.io/kashier-checkout.js',
      id: 'kashier-iFrame',
      'data-amount': options.amount,
      'data-hash': options.hash,
      'data-currency': options.currency_code,
      'data-orderId': options.order_id,
      'data-merchantId': options.merchantId,
      'data-mode': options.mode,
      'data-brandColor': options.color,
      'data-merchantRedirect': options.return_url,
      'data-redirectMethod': 'post',
      'data-metaData': options.metaData,
      'data-serverWebhook': options.notify_url,
      'data-display': options.lc.search(/ar/i) > 0 ? 'ar' : 'en',
    });

    $('body').append(script);
    var checkExist = setInterval(function () {
      if ($('#el-kashier-button').length) {
        $('#el-kashier-button').click();
        clearInterval(checkExist);
      }
    }, 100);
  }

  observer.observe(document.body, { childList: true });
  display_kashier_form($('form[provider="kashier"]'));
});
