# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import pprint
import json

from odoo import http
from odoo.http import request
from odoo.exceptions import ValidationError
import hmac
import hashlib
import binascii



_logger = logging.getLogger(__name__)


class KashierController(http.Controller):

    _payment_result = '/payment/kashier/result'
    _webhook_url = '/payment/kashier/webhook'

    @http.route(
        _payment_result , type='http', auth='public', methods=['GET', 'POST'], csrf=False ,website=True   )
    def kashier_checkout(self, **kwargs):
        transactionId = kwargs.get('transactionId')
        if transactionId:
            tx_sudo = request.env['payment.transaction'].sudo()._get_tx_from_feedback_data(
                    'kashier', kwargs
                )
            if self.validateSignature(tx_sudo.acquirer_id.kashier_key_secret,kwargs):

                _logger.info('Kashier: entering form_feedback with post data %s', pprint.pformat(kwargs))
                request.env['payment.transaction'].sudo()._handle_feedback_data('kashier', kwargs)

        return request.redirect('/payment/status')
    

    @http.route(_webhook_url, type='json', auth='public')
    def kashier_webhook(self):
        """ Process the `=pay` event sent by Kashier to the webhook.

        :return: An empty string to acknowledge the notification with an HTTP 200 response
        :rtype: str
        """
        event = json.loads(request.httprequest.data)
        _logger.info("event received:\n%s", pprint.pformat(event))
        try:
            if event['event'] == 'pay':
                checkout_session = event['data']

                # Check the source and integrity of the event
                data = {'reference': checkout_session['merchantOrderId'], 'merchantOrderId': checkout_session['merchantOrderId'], 'transactionId':checkout_session['transactionId'], 'paymentStatus':checkout_session['status']}
                request.env['payment.transaction'].sudo()._get_tx_from_feedback_data(
                    'kashier', data
                )
                request.env['payment.transaction'].sudo()._handle_feedback_data('kashier', data)
        except ValidationError:  # Acknowledge the notification to avoid getting spammed
            _logger.exception("unable to handle the event data; skipping to acknowledge")
        return 'ok'
    
    def validateSignature(self,secret ,request ):
       queryString = ""
       for key in request:
            if key == "signature" or key =="mode" :
              continue
            queryString = queryString + "&" + f'{key}=' + request[key]

       queryString = queryString[1:]
       secret = bytes(secret, 'utf-8')
       queryString  = queryString.encode()
       signature = hmac.new(secret, queryString, hashlib.sha256).hexdigest()
       if signature == request.get("signature"):
          return True
       else :
          return False

